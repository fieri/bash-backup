# baidupan-rapidupload
百度网盘秒传链接在线转存/生成/转换（全平台）

https://rapid.acg.uy

支持 iOS/Android/PC and more

# 预览

![支持转存](https://i.yusa.me/BqI9b1mQlQrL.png)
![支持生成](https://i.yusa.me/46Tnl9a4xw2w.png)
![支持转换](https://i.yusa.me/YXH7WwRvgW1z.png)
