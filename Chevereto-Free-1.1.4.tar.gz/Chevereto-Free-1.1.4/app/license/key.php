<?php
/* --------------------------------------------------------------------

                      `--/++++++++:.
                  `./ydNNMMMMMMMMMMmo.`
                -+hNMMMMCOMPRENMMMMMMmh-
              `oNMMMMMMMMLAMWEAMMMMMMMNy-
             .hMMMMMMMMCONCHETUMAREMMMMMMN+`
            +mMMMMMMMMMTENGOMQUEMVIVIRMMMMMo.                   .// :///////:./:  .:/+/:.
           :MMMMMMNNMMMMMMMMMMMMMMMMMMMMMMMMm/`                 /MN oyymMmyyo:Mm`-mNysyNd-
          .mMMMMd+:-sshMMMMMMMMMMMMMMMMMMMMMMd`                 /MN    yMs   `yo /Nm+:-/+-
          /NNMN+..    sMMMMMMMMNymNMMMMMNNdmMd`                 /MN    yMs        :shmmmh:
          oodm-`o:    yMMMMMMNmy-./hNMMN/. +mh`                 /MN    yMs       oy/``.sMm
          ``o- ..   `oMMMMMMyshh::``sMMy`///.y:                 /NN    sNs       -dNhyhmm+
           :.`+/`` `oMMMMMMMhmMyom+mNMMMdNoohhs                 `:-    .:.         -:/:-`
           -.-Ndd/smMMMMMMMMMMMMNNMMMMMMMmdNdMN.
           .o:dhyMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMo
            -  mMMMMMMMMMMMMMMMMMyyNhhhmmhsdMMM/          ```````` ```````    ````````  `````````
            `  +MMMMMMMMMMMMMMNyhNMhdNh-`.:-/Ns           dMNmmmm+ yMNmmmNNs` hMNmmmmm: yMNmmmmm:
             ` `hMmMMMMMMMMMMy/yMMMMMMMMMMN: ``           mM/      yMy   -NM: hMo       yMs
             `  `./MMMMMMMMMMNo:osyh+os+/..-+/            mMmmmmh` yMNdddmmo` hMNmmmmh  yMNmmmmd
                  +MMMMMMMMMMM+y//-```````/NN-            mM+....  yMh-/mNy`  hMo`````  yMs`````
                  +MMMMMMMMMMMMMNho/s/-:+dNMs             mM/      yMy  .yMd- hMhoo+oo- yMdoo+o+:
                  .mMMMMMMMMMMMMMMMMMMNddNMhs`            /o-      :o:   `/+/ /ooooooo- :oo+oooo:
           `       .sdMMMMMMMdNMMMMMMy/-+NmoMh
        .-..         `/hhhNMMy/dMMMMMNNNNNoNN:
    -:/-/.`           `-sdyydNd+/yhmmNMNhomm/
   -/:-                  -sNdshmd/::--//shy.
                          `:dMmhhdhsoo+/-sm`
                            `oNMMNm:     +d
                             `-hMMh`     `d`
                               `om.      :d`
                                 .-      +d`

  --------------------------------------------------------------------- */

$license = 'Free:version';