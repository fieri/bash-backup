<?php
define('G_APP_NAME', 'Chevereto Free');
define('G_APP_VERSION', '1.1.4');
define('G_APP_GITHUB_OWNER', 'Chevereto');
define('G_APP_GITHUB_REPO', 'Chevereto-Free');
define('G_APP_GITHUB_REPO_URL', 'https://github.com/' . G_APP_GITHUB_OWNER . '/' . G_APP_GITHUB_REPO);
define('CHEVERETO_INSTALLER_DOWNLOAD_URL', 'https://chevereto.com/download/file/installer');
