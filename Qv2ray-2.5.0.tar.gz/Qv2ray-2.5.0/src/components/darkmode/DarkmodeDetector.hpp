#pragma once

namespace Qv2ray::components::darkmode
{
    bool isDarkMode();
}
