#pragma once
#include "components/plugins/QvPluginHost.hpp"
namespace Qv2ray::core::kernel
{

}
