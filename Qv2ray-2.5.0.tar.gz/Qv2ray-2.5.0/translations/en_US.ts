<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>ConnectionInfoWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect/Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Connection as JSON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latency Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QR Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Ignored %1 complex config(s))</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not a subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete an item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to delete the current item?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectionItemWidget</name>
    <message>
        <source>Not Tested</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>connections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnectionWidget</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>500ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type: vmess + tls + ws</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0KB / 0KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportConfigWindow</name>
    <message>
        <source>Import file</source>
        <translation></translation>
    </message>
    <message>
        <source>Name/Prefix</source>
        <translation></translation>
    </message>
    <message>
        <source>Import Source</source>
        <translation></translation>
    </message>
    <message>
        <source>Existing File</source>
        <translation></translation>
    </message>
    <message>
        <source> secs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide Qv2ray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subscription Link</source>
        <translation></translation>
    </message>
    <message>
        <source>Import</source>
        <translation></translation>
    </message>
    <message>
        <source>Path</source>
        <translation></translation>
    </message>
    <message>
        <source>Select</source>
        <translation></translation>
    </message>
    <message>
        <source>VMess / QRCode</source>
        <translation></translation>
    </message>
    <message>
        <source>Go</source>
        <translation></translation>
    </message>
    <message>
        <source>Error List</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscriptions / Manually Input</source>
        <translation></translation>
    </message>
    <message>
        <source>Manually Input Connections</source>
        <translation></translation>
    </message>
    <message>
        <source>Route Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Open Route Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscription Manager</source>
        <translation></translation>
    </message>
    <message>
        <source>Open Subscription Manager</source>
        <translation></translation>
    </message>
    <message>
        <source>Connection Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Open Connection Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation></translation>
    </message>
    <message>
        <source>Select file to import</source>
        <translation></translation>
    </message>
    <message>
        <source>Capture QRCode</source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot find a valid QRCode from this region.</source>
        <translation></translation>
    </message>
    <message>
        <source>Import config file</source>
        <translation></translation>
    </message>
    <message>
        <source>Failed to check the validity of the config file.</source>
        <translation></translation>
    </message>
    <message>
        <source>Select an image to import</source>
        <translation></translation>
    </message>
    <message>
        <source>QRCode scanning failed</source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot find any QRCode from the image.</source>
        <translation></translation>
    </message>
    <message>
        <source>Import as Complex Config (Manually edit route rules and inbounds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QRCode File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Json Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open JSON Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A prefix to the imported connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection Share Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste share link here, one line for each.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InboundEditor</name>
    <message>
        <source>Inbound Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <source>Tag of this inbound entry</source>
        <translation></translation>
    </message>
    <message>
        <source>Listening</source>
        <translation></translation>
    </message>
    <message>
        <source>Hostname or IP Address</source>
        <translation></translation>
    </message>
    <message>
        <source>:</source>
        <translation></translation>
    </message>
    <message>
        <source>Port: 1080|80-85</source>
        <translation></translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation></translation>
    </message>
    <message>
        <source>Allocation Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Strategy</source>
        <translation></translation>
    </message>
    <message>
        <source>always</source>
        <translation></translation>
    </message>
    <message>
        <source>random</source>
        <translation></translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation></translation>
    </message>
    <message>
        <source>Concurrency</source>
        <translation></translation>
    </message>
    <message>
        <source>Sniffing Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Destination Override</source>
        <translation></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation></translation>
    </message>
    <message>
        <source>HTTP Inbound Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Timeout</source>
        <translation></translation>
    </message>
    <message>
        <source>Allow Transparent</source>
        <translation></translation>
    </message>
    <message>
        <source>User Level</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation></translation>
    </message>
    <message>
        <source>Username</source>
        <translation></translation>
    </message>
    <message>
        <source>Accounts</source>
        <translation></translation>
    </message>
    <message>
        <source>SOCKS Inbound Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Auth</source>
        <translation></translation>
    </message>
    <message>
        <source>Enable UDP</source>
        <translation></translation>
    </message>
    <message>
        <source>Local UDP IP</source>
        <translation></translation>
    </message>
    <message>
        <source>127.0.0.1</source>
        <translation></translation>
    </message>
    <message>
        <source>Dokodemo-Door Inbound Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>IP Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Not necessary when setting &quot;Follow Redirect&quot;</source>
        <translation></translation>
    </message>
    <message>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <source>Network</source>
        <translation></translation>
    </message>
    <message>
        <source>TCP</source>
        <translation></translation>
    </message>
    <message>
        <source>UDP</source>
        <translation></translation>
    </message>
    <message>
        <source>Follow Redirect</source>
        <translation></translation>
    </message>
    <message>
        <source>If you want to use tProxy, please go to Preference Window to enable this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MTProto Inbound Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>EMail Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Secret</source>
        <translation></translation>
    </message>
    <message>
        <source>SECRET</source>
        <translation></translation>
    </message>
    <message>
        <source>Inbound type not supported</source>
        <translation></translation>
    </message>
    <message>
        <source>The inbound type is not supported by Qv2ray (yet). Please use JsonEditor to change the settings</source>
        <translation></translation>
    </message>
    <message>
        <source>Inbound: </source>
        <translation></translation>
    </message>
    <message>
        <source>Removing a user</source>
        <translation></translation>
    </message>
    <message>
        <source>You haven&apos;t selected a user yet.</source>
        <translation></translation>
    </message>
    <message>
        <source>Add a user</source>
        <translation></translation>
    </message>
    <message>
        <source>This user exists already.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>JsonEditor</name>
    <message>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <source>Json Structure Preview</source>
        <translation></translation>
    </message>
    <message>
        <source>Format JSON</source>
        <translation></translation>
    </message>
    <message>
        <source>Json Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Json Contains Syntax Errors</source>
        <translation></translation>
    </message>
    <message>
        <source>Original Json may contain syntax errors. Json tree is disabled.</source>
        <translation></translation>
    </message>
    <message>
        <source>You must correct these errors before continuing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Syntax Errors</source>
        <translation></translation>
    </message>
    <message>
        <source>Please fix the JSON errors or remove the comments before continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JSON Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove All Comments</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Qv2ray</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscriptions</source>
        <translation></translation>
    </message>
    <message>
        <source>Add</source>
        <translation></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to toggle show/hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Speed Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear chart data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>  Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation></translation>
    </message>
    <message>
        <source>Upload/Download speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0.00 B/s
0.00 B/s</source>
        <translation></translation>
    </message>
    <message>
        <source>Data</source>
        <translation></translation>
    </message>
    <message>
        <source>Upload/Download Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0.00 B
0.00 B</source>
        <translation></translation>
    </message>
    <message>
        <source>Hide</source>
        <translation></translation>
    </message>
    <message>
        <source>Show</source>
        <translation></translation>
    </message>
    <message>
        <source>Sort connection list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By connection name, A-Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By connection name, Z-A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By data, Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By data, Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By latency, Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By latency, Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicating Connection(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to duplicate these connection(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> (Copy)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set auto connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set %1 as auto connect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot set system proxy</source>
        <translation></translation>
    </message>
    <message>
        <source>Both HTTP and SOCKS inbounds are not enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System proxy configured.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System proxy removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Subscriptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are subscriptions need to be updated, please go to subscriptions window to update them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>These subscriptions are out-of-date: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnected from: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Removing Connection(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kernel terminated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The kernel terminated unexpectedly:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To solve the problem, read the kernel log in the log text browser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit Qv2ray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to exit Qv2ray?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure to remove selected connection(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Locate Current Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to this</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set as automatically connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit as JSON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit as Complex Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate to the Same Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Latency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear Usage Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch to vCore log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch to Qv2ray log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugins</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutboundEditor</name>
    <message>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <source>Tag of this outbound setting</source>
        <translation></translation>
    </message>
    <message>
        <source>Host</source>
        <translation></translation>
    </message>
    <message>
        <source>Hostname or IP/IPv6 Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <source>Type</source>
        <translation></translation>
    </message>
    <message>
        <source>Socks</source>
        <translation></translation>
    </message>
    <message>
        <source>Use Mux</source>
        <translation></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation></translation>
    </message>
    <message>
        <source>Edit Connection Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stream Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mux Concurrency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Forward Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outbound Settings</source>
        <translation></translation>
    </message>
    <message>
        <source>UUID</source>
        <translation></translation>
    </message>
    <message>
        <source>Alter ID</source>
        <translation></translation>
    </message>
    <message>
        <source>Security</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>Password</source>
        <translation></translation>
    </message>
    <message>
        <source>Encryption Method</source>
        <translation></translation>
    </message>
    <message>
        <source>Level</source>
        <translation></translation>
    </message>
    <message>
        <source>OTA</source>
        <translation></translation>
    </message>
    <message>
        <source>Username</source>
        <translation></translation>
    </message>
    <message>
        <source>Unknown outbound type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The specified outbound type is not supported, this may happen due to a plugin failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward proxy has been disabled when using plugin outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown outbound.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The specified outbound type is invalid, this may be caused by a plugin failure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please use the JsonEditor or reload the plugin.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginManageWindow</name>
    <message>
        <source>Loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Not Loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin does not have settings widget.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disabling a plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This plugin will keep loaded until the next time Qv2ray starts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin not loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This plugin is not loaded, please enable or reload the plugin to continue.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PreferencesWindow</name>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UI Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darkmode UI Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Darkmode Tray Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Log Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>none</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inbound Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Listening Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SOCKS Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UDP Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Launch at Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>127.0.0.1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Connection Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>API Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Local DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom DNS List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only simple config is supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Build Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Extra Build Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Socks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network Toolbar Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply Network Speed Bar UI Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maximum log lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Core Executable Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray Assets Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check V2ray Core Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UDP Local IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This feature is not stable and no documentation is provided, please use it at your own risk!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>G:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Text/Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can config how the network speed toolbar looks like in this panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use Darkmode Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Item(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable tProxy Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>to this path: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray Network Toolbar is disabled and still under test. Add --withToolbarPlugin to enable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update is disabled by your vendor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicated port numbers detected, please check the port number settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid inbound listening address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open V2ray assets folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open V2ray core file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will append capabilities to the V2ray executable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray will copy your V2ray core to this path: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If anything goes wrong after enabling this, please check issue #57 or the link below:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray cannot copy one or both V2ray files from: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to setcap onto V2ray executable. You may need to run `setcap` manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tProxy is not supported on macOS and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply network toolbar settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All other modified settings will be applied as well after this object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start with boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Failed to set auto start option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray Core Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray path configuration check passed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current version of V2ray is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dangerous Operation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You will lose the advantage of TLS and make your connection under MITM attack.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This will (probably) make it easy to fingerprint your connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent Proxy Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Follow Redirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bypass CN Mainland</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced Route Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can configure route rules for all simple connection config here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Official Repo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Built Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stable Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Testing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transparent Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User-Agent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kernel Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>API SubSystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Kernel Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabling V2ray Integration will allow the kernel benefit from the V2ray routing engine.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray Integration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If not checked, these features will be disabled:

Advanced Routing Settings
Bypass CN websites and IPs
Direct connection of Local LAN addresses
Custom DNS Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray will allocate ports, for HTTP and SOCKS respectively, if enabled, for each kernel plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Port Allocation Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Page Y Axis Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ignored Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Advanced Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AllowInsecure By Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable &quot;AllowInsecure&quot; settings for all connections when importing.
This could resolve the certificate issues, but also could let one performing TLS MITM attack.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test Latency Periodcally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Run TCPing or ICMPing periodcally after connecting to a server.
Qv2ray will give a more accurate latency value if Enabled, but makes it easy to fingerprint the connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>These settings may be useful.
But could damage your server if improperly used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AllowInsecureCiphers By Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quiet Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Recent Jumplist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Curtom Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DNS Intercept</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>redirect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tproxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outbound Mark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Unsupported share link format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SS URI is too short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find the colon separator between method and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find the at separator between password and hostname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can&apos;t find the colon separator between hostname and port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VMess string should start with &apos;vmess://&apos;</source>
        <translation></translation>
    </message>
    <message>
        <source>VMess string should be a valid base64 string</source>
        <translation></translation>
    </message>
    <message>
        <source>JSON should not be empty</source>
        <translation></translation>
    </message>
    <message>
        <source>seems like a v1 vmess, we don&apos;t support it</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning</source>
        <translation></translation>
    </message>
    <message>
        <source>Qv2ray cannot load the config file from here:</source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot Start Qv2ray</source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot find a place to store config files.</source>
        <translation></translation>
    </message>
    <message>
        <source>Qv2ray has searched these paths below:</source>
        <translation></translation>
    </message>
    <message>
        <source>It usually means you don&apos;t have the write permission to all of those locations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray will now exit.</source>
        <translation></translation>
    </message>
    <message>
        <source>Failed to initialise Qv2ray</source>
        <translation></translation>
    </message>
    <message>
        <source>Please report if you think it&apos;s a bug.</source>
        <translation></translation>
    </message>
    <message>
        <source>You cannot run Qv2ray as root, please use --I-just-wanna-run-with-root if you REALLY want to do so.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> --&gt; USE IT AT YOUR OWN RISK!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Debug version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray Cannot Continue</source>
        <translation></translation>
    </message>
    <message>
        <source>You are running a lower version of Qv2ray compared to the current config file.</source>
        <translation></translation>
    </message>
    <message>
        <source>Please check if there&apos;s an issue explaining about it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Or submit a new issue if you think this is an error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dependency Missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This could be caused by a missing of `openssl` package in your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you are using an AppImage from Github Action, please report a bug.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot find openssl libs</source>
        <translation></translation>
    </message>
    <message>
        <source>Failed to determine the location of config file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray has found a config file, but it failed to be loaded due to some errors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A workaround is to remove the this file and restart Qv2ray:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Technical Details</source>
        <translation></translation>
    </message>
    <message>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray - A cross-platform Qt frontend for V2ray.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deprecated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAC is now deprecated and is not encouraged to be used anymore.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>It will be removed or be provided as a plugin in the future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAC will still work currently, but please switch to the V2ray built-in routing as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration Upgrade Failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unsupported config version number: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please upgrade firstly up to Qv2ray v2.0/v2.1 and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid ssd link: json: field %1 must exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid ssd link: json: field %1 must be valid port number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid ssd link: json: field %1 must be of type &apos;string&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>invalid ssd link: json: field %1 must be an array</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>skipping invalid ssd server: server must be an object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>skipping invalid ssd server: missing required field %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>skipping invalid ssd server: field %1 should be of type &apos;string&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid ssd link: should begin with ssd://</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid ssd link: base64 parse failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid ssd link: json parse failed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid ssd link: found non-object json, aborting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid ssd link: rc4-md5 encryption is not supported by v2ray-core</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Qv2ray Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Connection Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Connection Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Upload Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Download Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Uploaded Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Downloaded Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current Connection Latency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 - %2 (rate %3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>(Complex config)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>core executable file %1 does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cannot open core executable file %1 in read-only mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>core executable file %1 is an empty file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>core executable file %1 is too short to be executed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cannot deduce the type of core executable file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Windows PE executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>macOS Mach-O executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ELF x86 executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ELF amd64 executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ELF arm64 executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ELF arm executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>other ELF executable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unknown abi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normal Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Share Link Parser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Capability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection State Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Statistics Event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System Proxy Event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::common::QvCommandArgParser</name>
    <message>
        <source>Disable gRPC API subsystems.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explicitly run Qv2ray as root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Debug Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable manually set QT_SCALE_FACTOR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable plugin feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Qv2ray network toolbar plugin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::components::QvUpdateChecker</name>
    <message>
        <source>Qv2ray Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A new version of Qv2ray has been found:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::components::plugins::QvPluginHost</name>
    <message>
        <source>Cannot load plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cannot be loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This plugin was built against an older/newer version of the Plugin Interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please contact the plugin provider or report the issue to Qv2ray Workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabling a plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The plugin will become fully functional after restarting Qv2ray.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::core::handlers::KernelInstanceHandler</name>
    <message>
        <source>A plugin kernel failed to start. Please check the outbound settings.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::core::handlers::QvConfigHandler</name>
    <message>
        <source>Default Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Group does not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Update Subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 entrie(s) have been found from the subscription source, do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::core::kernel::V2rayKernelInstance</name>
    <message>
        <source>V2ray core executable not found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray core file cannot be opened, please ensure there&apos;s a file instead of a folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2Ray core is incompatible with your platform.<byte value="xd"/>
Expected core ABI is %1, but got actual %2.<byte value="xd"/>
Maybe you have downloaded the wrong core?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray assets path is not valid.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No geoip.dat in assets path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No geosite.dat in assets path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray core failed with an exit code: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray core returns empty string.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cannot start V2ray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray core settings is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The error is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invalid V2ray Instance Status.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>V2ray kernel failed to start.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qv2ray::ui::widgets::AutoCompleteTextEdit</name>
    <message>
        <source>You can not input space characters here.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QvInboundNodeModel</name>
    <message>
        <source>Missing or incorrect inputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QvOutboundNodeModel</name>
    <message>
        <source>Missing or incorrect inputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QvRuleNodeDataModel</name>
    <message>
        <source>Missing or incorrect inputs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RouteEditor</name>
    <message>
        <source>Route Editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Route Detail Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source IP Matches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Status</source>
        <translation></translation>
    </message>
    <message>
        <source>Add default inbound from global config</source>
        <translation></translation>
    </message>
    <message>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <source>Tag</source>
        <translation></translation>
    </message>
    <message>
        <source>Add outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Delete outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Edit outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Add Freedom outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Add blackhole outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Routes</source>
        <translation></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation></translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Add new route</source>
        <translation></translation>
    </message>
    <message>
        <source>Use Balancers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <source>Target IP List</source>
        <translation></translation>
    </message>
    <message>
        <source>Target Domain List</source>
        <translation></translation>
    </message>
    <message>
        <source>Network</source>
        <translation></translation>
    </message>
    <message>
        <source>TCP</source>
        <translation></translation>
    </message>
    <message>
        <source>UDP</source>
        <translation></translation>
    </message>
    <message>
        <source>Both</source>
        <translation></translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation></translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add From Global Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Black Hole</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Direct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected Inbound/Outbound Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A rule with no inbound connected means there&apos;s no inbound restriction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>General Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Strategy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule Order Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drag and drop to re-order the rules.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rule Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <source>TLS</source>
        <translation></translation>
    </message>
    <message>
        <source>BitTorrent</source>
        <translation></translation>
    </message>
    <message>
        <source>e.g. 80, 443, 8000-8080</source>
        <translation></translation>
    </message>
    <message>
        <source>Balancers</source>
        <translation></translation>
    </message>
    <message>
        <source>Users List</source>
        <translation></translation>
    </message>
    <message>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <source>Cannot Edit</source>
        <translation></translation>
    </message>
    <message>
        <source>This outbound entry is not supported by the GUI editor.</source>
        <translation></translation>
    </message>
    <message>
        <source>We will launch Json Editor instead.</source>
        <translation></translation>
    </message>
    <message>
        <source>Show rule details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A rule cannot be found: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocol list changed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Balancer is empty, not processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No inbound item found: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new tag has been used, we appended a postfix.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The new tag has been used, we appended a random string to the tag.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>To make this rule ready to use, you need to connect it to an outbound node.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please select a node from the graph to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Qv2ray entered an unknown state.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Inbound/Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No inbound tag found: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening JSON editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Unsupported Outbound Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Opening default outbound editor.</source>
        <translation></translation>
    </message>
    <message>
        <source>Renaming a tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New tag is empty, please try another.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New tag is the same as the original one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duplicate rule tag detected, please try another.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Added DIRECT outbound</source>
        <translation></translation>
    </message>
    <message>
        <source>Currently, this type of outbound is not supported by the editor.</source>
        <translation></translation>
    </message>
    <message>
        <source>Opening default inbound editor</source>
        <translation></translation>
    </message>
    <message>
        <source>Removed a balancer entry.</source>
        <translation></translation>
    </message>
    <message>
        <source>Rename tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add an Inbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add an Outbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Misc Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RouteSettingsMatrix</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lines start with &quot;geoip:&quot; or &quot;geosite:&quot; will have its autocompletion from geoip.dat and geosite.dat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use built-in route schemes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import route scheme from file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export route scheme to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Built-in Schemes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import Scheme...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export Scheme...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Domain Strategy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RouteSettingsMatrixWidget</name>
    <message>
        <source>empty scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>v2rayN preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import scheme &apos;%1&apos; made by &apos;%2&apos;? <byte value="xd"/>
 Description: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importing Scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exporting Scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Scheme name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unnamed Scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The author is too lazy to leave a comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your route scheme has been successfully exported!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>QvRoute Schemes(*.json)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenShot</name>
    <message>
        <source>ScreenShot</source>
        <translation></translation>
    </message>
    <message>
        <source>Size</source>
        <translation></translation>
    </message>
    <message>
        <source>FG</source>
        <translation></translation>
    </message>
    <message>
        <source>Screen Shot</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SpeedPlotView</name>
    <message>
        <source>Total Upload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total Download</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StreamSettingsWidget</name>
    <message>
        <source>Stream Settings Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Transport Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TLS Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SOCK Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TCP Fast Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Protocol Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Request</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MTU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TTI (ms)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uplink Capacity (MB/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Congestion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downlink Capacity (MB/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Read Buffer Size (MB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Write Buffer Size (MB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow Insecure Certificates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tProxy Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Allow Insecure Ciphers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubscriptionEditor</name>
    <message>
        <source>Reload Subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Would you like to reload the subscription?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Deleting a subscription</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All connections will be moved to default group, do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>misc</name>
    <message>
        <source>B</source>
        <comment>bytes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>KiB</source>
        <comment>kibibytes (1024 bytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MiB</source>
        <comment>mebibytes (1024 kibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GiB</source>
        <comment>gibibytes (1024 mibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TiB</source>
        <comment>tebibytes (1024 gibibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PiB</source>
        <comment>pebibytes (1024 tebibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EiB</source>
        <comment>exbibytes (1024 pebibytes)</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>/s</source>
        <comment>per second</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>w_PluginManager</name>
    <message>
        <source>Plugin Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Library Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Capability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Special Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Manually Edit Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Metadata</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin Not Loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Local Plugin Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online help about plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>w_SubscribeEditor</name>
    <message>
        <source>SubscribeEditor</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscription List</source>
        <translation></translation>
    </message>
    <message>
        <source>Add Subscription</source>
        <translation></translation>
    </message>
    <message>
        <source>Remove Subscription</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscription Details</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscription Name</source>
        <translation></translation>
    </message>
    <message>
        <source>Subscription Address</source>
        <translation></translation>
    </message>
    <message>
        <source>Update Interval</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Last Updated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connection List</source>
        <translation></translation>
    </message>
    <message>
        <source>Update Subscription Data</source>
        <translation></translation>
    </message>
</context>
</TS>
