Qv2ray Dependencies Directory for Windows x86

THIS IS A PLACEHOLDER WHICH ALLOWS GIT TO INCLUDE THIS DIRECTORY

If you want to build Qv2ray on Windows, please download the gRPC and 
protobuf headers and libraries according to your CPU architecture:

- Go to https://github.com/Qv2ray/Qv2ray-deps/releases
- Download "Qv2ray-deps-x86-windows.7z"

Then extract the 7z zipball here.

Make sure these file exists: 
- Qv2raySourceRoot/libs/x86-windows/tools/grpc/grpc_cpp_plugin.exe
- Qv2raySourceRoot/libs/x86-windows/tools/protobuf/protoc.exe

# ======================================================================

32 位 Windows 的 Qv2ray 依赖文件夹
这个文件的存在使得 git 可以添加此文件夹

如果你想在 Windows 下编译 Qv2ray， 请遵循这些步骤下载 gRPC 和 protobuf 头文件
和库文件：

- 访问 https://github.com/Qv2ray/Qv2ray-deps/releases
- 下载 "Qv2ray-deps-x86-windows.7z"

然后将这个 7z 压缩包解压到这里

请确保这些文件存在：
- Qv2ray源码根目录/libs/x86-windows/tools/grpc/grpc_cpp_plugin.exe
- Qv2ray源码根目录/libs/x86-windows/tools/protobuf/protoc.exe
