package pcsdownload

import (
	"github.com/iikira/BaiduPCS-Go/internal/pcsfunctions"
)

type (
	DownloadStatistic struct {
		pcsfunctions.Statistic
	}
)
