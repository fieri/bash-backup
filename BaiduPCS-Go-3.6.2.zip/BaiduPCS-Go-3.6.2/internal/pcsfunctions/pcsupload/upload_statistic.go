package pcsupload

import (
	"github.com/iikira/BaiduPCS-Go/internal/pcsfunctions"
)

type (
	UploadStatistic struct {
		pcsfunctions.Statistic
	}
)
