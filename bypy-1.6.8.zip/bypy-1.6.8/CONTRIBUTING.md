# Contributing Guideline

First of all, thank you very much for submitting codes / pull requests to this little project. :smile:

I want the whole project to be licensed under the permissive **MIT license**, so that anybody can use it pretty much anyway they want. So by submitting codes / changes to this project, you agree to license all of them under the **MIT license** to this project.

--------

首先，非常感谢你对这个小工具提交的代码/改动。 :smile:

我希望整个项目都是使用**MIT授权协议**的，好让每个人使用的时候几乎不受任何限制。所以通过向这个项目提交代码/改动，你同意将它们全部用**MIT协议**授权给这个项目。

