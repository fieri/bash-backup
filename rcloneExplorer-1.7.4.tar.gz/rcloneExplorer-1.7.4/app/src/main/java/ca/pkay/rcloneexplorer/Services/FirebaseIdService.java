package ca.pkay.rcloneexplorer.Services;

import com.google.firebase.iid.FirebaseInstanceIdService;

public class FirebaseIdService extends FirebaseInstanceIdService {
}
